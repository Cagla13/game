using System.Collections;
using UnityEngine;

public class AnaKarakter : MonoBehaviour
{
    public float timeRemaining = 10;

    void Start()
    {
        StartCoroutine(Countdown());
    }

    IEnumerator Countdown()
    {
        while (timeRemaining > 0)
        {
            UpdateTimerText();
            yield return new WaitForSeconds(1);
            timeRemaining--;
        }

        Debug.Log("S�re bitti");
        Application.LoadLevel(Application.loadedLevel);
    }

    void UpdateTimerText()
    {
        int minutes = Mathf.FloorToInt(timeRemaining / 60);
        int seconds = Mathf.FloorToInt(timeRemaining % 60);
        Debug.Log("Kalan s�re: " + minutes.ToString("00") + ":" + seconds.ToString("00"));
    }
}

