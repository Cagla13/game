using UnityEngine;
using UnityEngine.AI;

public class basityapayzeka : MonoBehaviour
{
    public Transform target; // hedefi se�tiriyoruz inspector'dan
    private NavMeshAgent agent; // NavMeshAgent'i yine tespit ettiriyoruz inspector'dan yine

    void Start()
    {
        agent = GetComponent<NavMeshAgent>(); // NavMeshAgent'a m�dahale olaca��ndan component olarak atanm�� bu de�eri bulduruyoruz. Ayn�s�n� collision s�recinde de yap�yorduk hat�rlarsan�z.
    }

    void Update()
    {
        if (target != null)
        {
            agent.SetDestination(target.position); // hedefin art�k pozisyonu neredeyse oraya y�nlenmesini sa�lat�yoruz 
        }
    }
}

