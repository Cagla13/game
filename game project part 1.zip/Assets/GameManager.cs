using UnityEngine;
using UnityEngine.SceneManagement;
public class GameManager : MonoBehaviour
{
    public Movement movement;
    public void PlayerWins()
    {
        Debug.Log("You win! Mission accomplished!");
        Application.LoadLevel(Application.loadedLevel);
    }

    public void PlayerLoses()
    {
        Debug.Log("Mission failed! You lose!");
        Application.LoadLevel(Application.loadedLevel);
    }

    void OnTriggerEnter(Collider other)
    {
        Debug.Log("OnTriggerEnter is called!");
        if (other.CompareTag("Finish"))
        {
            Debug.Log("Finish line reached!");
            PlayerWins();
        }
        if (other.CompareTag("Enemy"))
        {
            Debug.Log("Wasted!");
            PlayerLoses();
        }
    }
}

