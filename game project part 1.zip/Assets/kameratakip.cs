using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class kameratakip : MonoBehaviour
{
    public Transform target; // Kameran�n takip edece�i hedef (oyuncu karakteri)
    public float smoothing = 5f; // Kameran�n hedefe do�ru hareketindeki yumu�akl�k derecesi

    Vector3 offset; // Hedef ile kamera aras�ndaki ba�lang�� mesafesi

    void Start()
    {
        // Hedef ile kameran�n ba�lang��taki pozisyon fark�n� hesapla
        offset = transform.position - target.position;
    }

    void FixedUpdate()
    {
        // Hedefin yeni pozisyonunu hesapla (offset'i ekleyerek)
        Vector3 targetCamPos = target.position + offset; //mevcut sapmay� asl�nda do�rudan al�yor. Bu y�zden offset'le merkez noktas� nereden d�n�yor ona bakmam�z gerekiyor.
        // Kameray�, mevcut pozisyonundan hedefin yeni pozisyonuna do�ru belirli bir yumu�akl�kta hareket ettir
        transform.position = Vector3.Lerp(transform.position, targetCamPos, smoothing * Time.deltaTime); // T�pk� PlayerMovement'ta yapt���m�z gibi zaman fark�n� �ekiyoruz.
    }
}
