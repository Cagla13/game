using System.Collections; // buras� default
using System.Collections.Generic; // buras� da default
using UnityEngine; // buras� da default

public class oyuncu_hareketi : MonoBehaviour
{
    public float moveSpeed = 5f; // Oyuncunun hareket h�z� (�arpan de�er olarak artaca�� i�in dikkatli se�emk lza�m.)
    private Rigidbody rb; // Rigidbody komponenti i�in bir referans (ilk referans buras�. ama bu da olmadan �nce rigidbody eklenmeli. Eklenmese olur mu? Olur ama unutulabilir.)
    private Vector3 moveInput; // Hareket girdisini tutacak vekt�r
    private Vector3 moveVelocity; // Hesaplanan hareket h�z�

    void Start()
    {
        rb = GetComponent<Rigidbody>(); // Rigidbody komponentini al (bunu yapabilmeniz i�in �ncelikle rigidbody'nin component olarak physics'ten atanmas� laz�m.
    }

    void Update()
    {
        // Yatay ve dikey girdileri al (WASD veya ok tu�lar�. Bunlar default olarak Unity'de var zaten. Ekstra �rne�in X falan demenize gerek yok. Ama diyebilirsiniz de.)
        moveInput = new Vector3(Input.GetAxisRaw("Horizontal"), 0f, Input.GetAxisRaw("Vertical"));
        moveVelocity = moveInput.normalized * moveSpeed; // Normalle�tirilmi� hareket vekt�r�n� ve h�z� hesapla
    }

    void FixedUpdate()
    {
        // Rigidbody'e hareket h�z�n� uygula, b�ylece karakter hareket eder
        rb.MovePosition(rb.position + moveVelocity * Time.fixedDeltaTime); //DeltaTime zaman fark�n� �ekiyor en son yap�lan vuru�la. O y�zden movevelocity �st�ne ekleniyor.
    }
}
