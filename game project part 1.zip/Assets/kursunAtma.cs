using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class kursunAtma : MonoBehaviour
{

    public float damage = 10f;
    public float range = 100f;
    public GameObject kursun;
    public float kursunSpeed = 30f;

    void Update()
    {

        if (Input.GetKeyDown(KeyCode.Mouse0))
        {
            Shoot();
        }


    }
    void Shoot()
    {
        Color color = Random.ColorHSV(0f, 1f, 1f, 1f, 0.5f, 1f);
        GameObject bullet = Instantiate(kursun, transform.position, Quaternion.identity);
        Rigidbody rb = bullet.AddComponent<Rigidbody>();
        bullet.GetComponent<Renderer>().material.color = color;
        rb.useGravity = false;
        rb.velocity = transform.forward * kursunSpeed;


        Destroy(bullet, 3f);
    }
}
