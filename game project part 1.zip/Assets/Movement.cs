using System;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class Movement : MonoBehaviour
{
    public float moveSpeed = 2.0f;
    public float turnSpeed = 100.0f;
    public TextMeshProUGUI scoreText;


    public int score = 0;

    void Start()
    {
        scoreText = GetComponent<TextMeshProUGUI>();
        UpdateScoreDisplay();

    }

    void Update()
    {
        float moveHorizontal = Input.GetAxis("Horizontal") * moveSpeed * Time.deltaTime;
        float moveVertical = Input.GetAxis("Vertical") * moveSpeed * Time.deltaTime;

        transform.Translate(moveHorizontal, 0, moveVertical);

        if (Input.GetAxis("Mouse X") != 0)
        {
            float turn = Input.GetAxis("Mouse X") * turnSpeed * Time.deltaTime;
            transform.Rotate(0, turn, 0, Space.World);

        }
    }

    public void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.CompareTag("Pickup"))
        {
            score += 5;
            UpdateScoreDisplay();
            Destroy(other.gameObject);
        }

    }

    public void UpdateScoreDisplay()
    {
        Debug.Log("Score: " + score);
    }

}